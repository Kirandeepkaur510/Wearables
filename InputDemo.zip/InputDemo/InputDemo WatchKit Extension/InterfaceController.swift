//
//  InterfaceController.swift
//  InputDemo WatchKit Extension
//
//  Created by MacStudent on 2019-03-04.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    @IBOutlet weak var responseLabel: WKInterfaceLabel!
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func replyButon() {
        print("Button clicked")
        //when person clicks the button  , show the input UI
        let sugestedResponse = ["Good" , "Bad" , "Stressed" , "Tired"]
        presentTextInputController(withSuggestions: sugestedResponse, allowedInputMode: .plain) { (results) in

            // 2. write your code to process the person's response
            if (results != nil && results!.count > 0) {
               var userResponse = results?.first as? String
                self.responseLabel.setText(userResponse)
            }
        }
    }
}
